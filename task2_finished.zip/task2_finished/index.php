<?php
require 'functions.php';

checkCountry();

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<?php require 'header.php'?>
<body>
<h1>Home</h1>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. A dicta dolores eaque earum eius facilis laboriosam nemo numquam obcaecati placeat possimus reiciendis rerum sequi, tenetur, voluptas. A aperiam aspernatur assumenda cum delectus dolore exercitationem, ipsum iure laborum natus obcaecati quas quisquam quo repellendus reprehenderit sint tempore temporibus unde? Accusamus, saepe.</p>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>