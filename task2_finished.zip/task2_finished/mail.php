<?php

use PHPMailer\PHPMailer\PHPMailer;

require 'config.php';

$firstName = htmlspecialchars($_POST['first_name']);
$lastName = htmlspecialchars($_POST['last_name']);
$email = filter_var(htmlspecialchars($_POST['email']), FILTER_VALIDATE_EMAIL);
$message = htmlspecialchars($_POST['message']);

if (empty($firstName) || empty($lastName) || empty($message)) {
    header("Location:contact.php?error=empty_fields");
    return;
}

if (!$email) {
    header("Location:contact.php?error=invalid_email");
    return;
}


$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = MAIL['Host'];
    $mail->SMTPAuth = MAIL['SMTPAuth'];
    $mail->Port = MAIL["Port"];
    $mail->Username = MAIL["Username"];
    $mail->Password = MAIL['Password'];                               //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    $mail->setFrom($email, $firstName . " " . $lastName);
    $mail->addAddress('support@example.com', 'Support');     //Add a recipient

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Support';
    $mail->Body    = "
        <p>First name: $firstName</p>
        <p>Last name: $lastName</p>
        <p>Email: $email</p>
        <p>Message: $message</p>
    ";

    $mail->send();

    header("Location:contact.php?success=true");
} catch (Exception $e) {
    header("Location:contact.php?error=sending_email");

    return;
}