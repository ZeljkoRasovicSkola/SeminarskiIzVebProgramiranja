<?php

require 'vendor/autoload.php';

const MAIL = [
    "Host" => 'sandbox.smtp.mailtrap.io',
    "SMTPAuth" => true,
    "Port" => 2525,
    "Username" => '57c0bbb1633087',
    "Password" => '3df93f47d7d27a'
];

const DB = [
    "host" => "localhost",
    "name" => "iws",
    "username" => "root",
    "password" => "",
];
