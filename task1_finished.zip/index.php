<?php
require 'config.php';
require 'functions.php';
require 'vendor/autoload.php';

use \Detection\MobileDetect;

$ipAddress = getIpAddress();
$ipAddress = "127.0.01" ? "119.14.26.0" : $ipAddress;

$cookie = $_COOKIE["visited"] ?? "";

$detect = new MobileDetect();

if (!isset($_COOKIE['VISITED'])) {

    $response = getCurlData("http://ip-api.com/json/$ipAddress?fields=$apiFields");
    $apiData = json_decode($response, true);

    $userAgent = $detect->getUserAgent();
    // $userAgent = $_SERVER["HTTP_USER_AGENT"] ?? "unknown";

    $deviceType = $detect->isMobile() ? ($detect->isTablet() ? "tablet" : "phone") : "computer";

    $country = $apiData['country'] ?? "unknown";
    $proxy = $apiData['proxy'] ?? 0;
    $isp = $apiData['isp'] ?? "unknown";

    insertIntoLog($userAgent, $ipAddress, $deviceType, $country, $proxy, $isp);
    setcookie("VISITED", "YES", time() + 10);
}


?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Task 1</title>
</head>
<body>
<h1>Welcome</h1>
<p>
    <a href="show_logs.php">Show logs</a>
</p>
</body>
</html>