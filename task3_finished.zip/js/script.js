$(document).ready(function () {

    const danger = $('#danger').DataTable({

        ajax: {
            url: "ajax/getDangerData.php",
            dataType: "json",
            type: "POST"
        },
        columnDefs: [
            {targets: [1], visible: false} // Second column (id) is hidden
        ],
        language: {
            search: "Filter records:", // Custom text for the search box
            lengthMenu: "Display _MENU_ records per page", // Text for the page length dropdown
            info: "Showing _START_ to _END_ of _TOTAL_ entries", // Info text at the bottom
            paginate: {
                first: "First",
                last: "Last",
                next: "Next",
                previous: "Previous"
            },
            infoEmpty: "No records available", // When there are no records to show
            infoFiltered: "(filtered from _MAX_ total records)", // After filtering the data
            zeroRecords: "No matching records found" // When no records match the search
        },
        dom: 'Blfrtip',
        buttons: [
            {
                extend: 'copyHtml5',
                exportOptions: {
                    columns: ':visible'
                },
                text: '<i class="bi bi-clipboard"></i> Copy',
                className: 'btn btn-primary'
            },
            {
                extend: 'excelHtml5',
                exportOptions: {
                    columns: [0, 1, 2, 3, 4, 5, 6],
                },
                text: '<i class="bi bi-file-earmark-excel"></i>  Excell',
                className: 'btn btn-success'
            },
            {
                extend: 'pdfHtml5',
                exportOptions: {
                    columns: [0, 1, 2, 3, 4, 5, 6],
                    orientation: 'landscape',
                    pageSize: 'LEGAL'
                },
                text: '<i class="bi bi-file-pdf"></i> PDF',
                className: 'btn btn-danger'
            }
        ],


    });
});