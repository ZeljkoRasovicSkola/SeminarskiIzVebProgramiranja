<?php
$GLOBALS['pdo'] = connectDatabase($dsn, $pdoOptions);

/**
 * Function tries to connect to database using PDO.
 *
 * @param string $dsn
 * @param array $pdoOptions
 * @return PDO
 */
function connectDatabase(string $dsn, array $pdoOptions): PDO
{

    try {
        $pdo = new PDO($dsn, PARAMS['USER'], PARAMS['PASSWORD'], $pdoOptions);
    } catch (\PDOException $e) {
        var_dump($e->getCode());
        throw new \PDOException($e->getMessage());
    }

    return $pdo;
}


/**
 * Function detects ip address of the request.
 * It returns valid ip address or unknown word.
 *
 * @return string
 */
function getIpAddress(): string
{

    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }

    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        $ip = "unknown";
    }

    return $ip;
}

/**
 * Inserts detected data in the log table
 *
 * @param string $userAgent User agent string
 * @param string $ipAddress IP address
 * @param string $deviceType Type of device
 * @param string $country Country of IP address, retrieved from the API
 * @param bool $proxy Value that indicated is IP address from a proxy, retrieved from the API
 * @param string $isp Name of the Internet service provider, retrieved from the API
 * @return void
 */
function insertIntoLog(string $userAgent, string $ipAddress, string $deviceType, string $country, bool $proxy, string $isp): void
{

    $sql = "INSERT INTO log(user_agent, ip_address, country, proxy, device_type, isp) 
            VALUES(:userAgent, :ipAddress, :country, :proxy, :deviceType, :isp)";

    $stmt = $GLOBALS['pdo']->prepare($sql);
    $stmt->bindValue(':userAgent', $userAgent, PDO::PARAM_STR);
    $stmt->bindValue(':ipAddress', $ipAddress, PDO::PARAM_STR);
    $stmt->bindValue(':country', $country, PDO::PARAM_STR);
    $stmt->bindValue(':proxy', $proxy, PDO::PARAM_INT);
    $stmt->bindValue(':deviceType', $deviceType, PDO::PARAM_STR);
    $stmt->bindValue(':isp', $isp, PDO::PARAM_STR);

    $stmt->execute();
}

/**
 * Performs cURL session and returns the transfer as a string
 *
 * @param $url
 * @return string
 */
function getCurlData($url): string
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($ch);
    curl_close($ch);

    return $result;
}

/**
 * Returns data from the log table in the form of an array
 *
 * @return array
 */
function getLogData(): array
{
    $sql = "SELECT id_log, user_agent, ip_address, country, DATE_FORMAT(date_time, '%d/%m/%Y %H:%i:%s') AS date, device_type, proxy, isp FROM log ORDER BY date DESC";
    $stmt = $GLOBALS['pdo']->prepare($sql);
    $stmt->execute();

    return $stmt->fetchAll();

}