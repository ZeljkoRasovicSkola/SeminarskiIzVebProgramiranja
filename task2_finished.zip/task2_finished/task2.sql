CREATE TABLE `danger`
(
    `id`          INT AUTO_INCREMENT
        PRIMARY KEY,
    `ip_address`  VARCHAR(255)                          NULL,
    `user_agent`  VARCHAR(255)                          NULL,
    `device_type` VARCHAR(255)                          NULL,
    `country`     VARCHAR(255)                          NULL,
    `access_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP() NULL
);

