<?php
require "config.php";

use Detection\MobileDetect;
use PHPMailer\PHPMailer\PHPMailer;


$pdo = new PDO("mysql:host=" . DB["host"] . ";dbname=" . DB["name"], DB["username"], DB["password"]);

if ($pdo->errorCode()) {
    die("Error connecting to the database.");
}

function detectMobile(): bool | string
{
    $detect = new MobileDetect();
    $isMobile = $detect->isMobile() || $detect->isTablet();

    if (!$isMobile) return false;

    return $detect->isiOS() ? "https://www.examples.com/defaultIos.apk" : "https://www.examples.com/defaultAndroid.apk";
}

function getIpAddress(): string
{

    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }

    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        $ip = "unknown";
    }

    if ($ip === "::1" || $ip === "127.0.0.1") {
        return "147.91.199.142";
    }

    return $ip;
}

function getCurlData($url): string
{
    // https://www.php.net/manual/en/book.curl.php

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($ch);
    curl_close($ch);

    return $result;
}

function checkCountry(): void
{
    global $pdo;

    $ip = getIpAddress();
    $response = getCurlData("http://ip-api.com/json/$ip?fields=country");

    $data = json_decode($response);

    if ($data->country !== "Colombia" && $data->country !== "Mexico") return;

    $detect = new MobileDetect();

    $userAgent = $detect->getUserAgent();
    $deviceType = $detect->isMobile() ? ($detect->isTablet() ? "tablet" : "mobile") : "desktop";

    $stmt = $pdo->prepare("INSERT INTO `danger` (`ip_address`, `user_agent`, `device_type`, `country`) VALUES (?, ?, ?, ?)");
    $stmt->execute([$ip, $userAgent, $deviceType, $data->country]);

    try {
        $mail = new PHPMailer(true);

        $mail->isSMTP();
        $mail->Host = MAIL['Host'];
        $mail->SMTPAuth = MAIL['SMTPAuth'];
        $mail->Port = MAIL["Port"];
        $mail->Username = MAIL["Username"];
        $mail->Password = MAIL['Password'];

        $mail->setFrom("danger@example.com", "Danger");
        $mail->addAddress('danger@example.com', 'Danger');

        //Content
        $mail->isHTML(true);
        $mail->Subject = 'Danger';
        $mail->Body    = "
            <p>IP Address: $ip</p>
            <p>User Agent: $userAgent</p>
            <p>Device type: $deviceType</p>
            <p>Country: {$data->country}</p>
        ";

        $mail->send();
    } catch (Exception $e) {
        //
    }

    die("Access denied for your country!");
}

